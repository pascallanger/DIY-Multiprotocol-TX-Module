#ifndef WiringPrivate_h
#define WiringPrivate_h

#endif